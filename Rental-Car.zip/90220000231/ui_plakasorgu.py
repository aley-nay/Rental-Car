# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'plakasorgu.ui'
##
## Created by: Qt User Interface Compiler version 6.6.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHeaderView, QLabel, QLineEdit,
    QMainWindow, QMenuBar, QPushButton, QSizePolicy,
    QStatusBar, QTableWidget, QTableWidgetItem, QWidget)

class ui_plakasorgu(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(800, 600)
        MainWindow.setStyleSheet(u"background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #FFDAB9, stop:1 #FFA07A);\n"
"color: #FF8A65;\n"
"font-weight:800;\n"
"font-size:14px;")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.tableWidget = QTableWidget(self.centralwidget)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setGeometry(QRect(110, 250, 561, 211))
        self.lineEdit_plaka = QLineEdit(self.centralwidget)
        self.lineEdit_plaka.setObjectName(u"lineEdit_plaka")
        self.lineEdit_plaka.setGeometry(QRect(214, 160, 306, 24))
        self.label_18 = QLabel(self.centralwidget)
        self.label_18.setObjectName(u"label_18")
        self.label_18.setGeometry(QRect(130, 160, 78, 24))
        font = QFont()
        font.setBold(True)
        font.setItalic(True)
        self.label_18.setFont(font)
        self.pushButton_ara = QPushButton(self.centralwidget)
        self.pushButton_ara.setObjectName(u"pushButton_ara")
        self.pushButton_ara.setGeometry(QRect(570, 160, 80, 24))
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 800, 24))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Plaka Sorgulama Ekrani ฅ^•ﻌ•^ฅ", None))
        self.label_18.setText(QCoreApplication.translate("MainWindow", u"Plaka", None))
        self.pushButton_ara.setText(QCoreApplication.translate("MainWindow", u"Ara", None))
    # retranslateUi

